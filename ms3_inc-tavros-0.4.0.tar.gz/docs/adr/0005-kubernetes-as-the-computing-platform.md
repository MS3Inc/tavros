# Kubernetes as the Computing Platform

* Status: accepted
* Deciders: @k2merlinsix, @jam01, Mohammad Naeem
* Date: 2020-08

## Context and Problem Statement

What should be our base platform?

## Decision Drivers <!-- optional -->

* Existing tooling and integrations to speed up delivery

## Decision Outcome

We'll use Kubernetes as Tavros's computing platform. The adoption and support for Kubernetes has been evident for some time, most importantly tools like Kops, Helm, Operators, and Ansible's Kubernetes modules, make a great base for us to focus on delivering our platform.
