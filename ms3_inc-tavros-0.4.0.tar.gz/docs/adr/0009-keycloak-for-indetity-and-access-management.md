# Keycloak for Identity and Access Management

* Status: accepted
* Deciders: Mohammad Naeem
* Date: 2020-08

## Context and Problem Statement

To provide user identity and access management, what component do we use?

## Decision Outcome

We'll use Keycloak for identity and access management.

## Links <!-- optional -->

* [Keycloak](https://www.keycloak.org/)
